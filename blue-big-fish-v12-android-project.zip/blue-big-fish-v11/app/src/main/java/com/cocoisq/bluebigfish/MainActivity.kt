package com.cocoisq.bluebigfish

import android.app.Activity
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DailyCount {
    private const val PREF = "blue_fish_daily"
    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.TAIWAN).format(Date())

    fun count(c: Context): Int {
        val p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        if (p.getString("day", "") != today()) {
            p.edit().putString("day", today()).putInt("count", 0).apply()
        }
        return p.getInt("count", 0)
    }

    fun tap(c: Context): Int {
        val p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val n = count(c) + 1
        p.edit().putInt("count", n).apply()
        update(c)
        return n
    }

    fun update(c: Context) {
        val manager = AppWidgetManager.getInstance(c)
        val ids = manager.getAppWidgetIds(ComponentName(c, FishWidget::class.java))
        ids.forEach { FishWidget.render(c, manager, it, false) }
    }
}

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.addJavascriptInterface(object {
            @JavascriptInterface fun getCount() = DailyCount.count(this@MainActivity)
            @JavascriptInterface fun onTap() = DailyCount.tap(this@MainActivity)
        }, "AndroidBridge")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }
}

class FishWidget : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        if (intent.action == ACTION_TAP) {
            val p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            val phrase = PHRASES.random()
            val token = p.getLong("phrase_token", 0L) + 1L
            p.edit().putString("phrase", phrase).putLong("phrase_token", token).apply()

            DailyCount.tap(c)
            playSqueak(c)

            val manager = AppWidgetManager.getInstance(c)
            val ids = manager.getAppWidgetIds(ComponentName(c, FishWidget::class.java))
            ids.forEach { render(c, manager, it, true) }

            handler.postDelayed({
                val current = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                if (current.getLong("phrase_token", 0L) == token) {
                    current.edit().putString("phrase", "").apply()
                    val m = AppWidgetManager.getInstance(c)
                    m.getAppWidgetIds(ComponentName(c, FishWidget::class.java))
                        .forEach { render(c, m, it, false) }
                }
            }, 1000L)

            handler.postDelayed({
                val m = AppWidgetManager.getInstance(c)
                m.getAppWidgetIds(ComponentName(c, FishWidget::class.java))
                    .forEach { render(c, m, it, false) }
            }, 190L)
        } else {
            val manager = AppWidgetManager.getInstance(c)
            manager.getAppWidgetIds(ComponentName(c, FishWidget::class.java))
                .forEach { render(c, manager, it, false) }
        }
    }

    companion object {
        private const val ACTION_TAP = "com.cocoisq.bluebigfish.TAP"
        private const val PREF = "blue_fish_daily"
        private val PHRASES = listOf("好了", "不要點了", "幹嘛", "啊", "哦鯨鯨")
        private val handler = Handler(Looper.getMainLooper())

        private fun playSqueak(c: Context) {
            try {
                val soundFile = java.io.File(c.cacheDir, "widget-squeak.wav")
                if (!soundFile.exists()) {
                    c.assets.open("squeak.wav").use { input ->
                        soundFile.outputStream().use { output -> input.copyTo(output) }
                    }
                }
                val player = MediaPlayer()
                player.setDataSource(soundFile.absolutePath)
                player.setOnCompletionListener { it.release() }
                player.setOnErrorListener { mp, _, _ -> mp.release(); true }
                player.prepare()
                player.start()
            } catch (_: Exception) {
                // Keep widget interaction working even if a device cannot play the asset.
            }
        }

        fun render(c: Context, manager: AppWidgetManager, id: Int, squish: Boolean) {
            val views = RemoteViews(c.packageName, R.layout.widget)
            val prefs = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            views.setTextViewText(R.id.widget_count, "被戳了 ${DailyCount.count(c)} 次")
            views.setTextViewText(R.id.widget_phrase, prefs.getString("phrase", "") ?: "")
            views.setImageViewResource(
                R.id.widget_maid,
                if (squish) R.drawable.maid_squish else R.drawable.maid
            )
            val tapIntent = Intent(c, FishWidget::class.java).setAction(ACTION_TAP)
            val pending = PendingIntent.getBroadcast(
                c, id, tapIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_maid, pending)
            manager.updateAppWidget(id, views)
        }
    }
}
